<?php

function generate_no_formulir() {
    $db = \Config\Database::connect();
    
    // Get total records from pengembalian_formulir
    $total = $db->table('pengembalian_formulir')->countAllResults();
    
    // Add 1 to current count and format to 3 digits
    $next_number = $total + 1;
    return str_pad($next_number, 3, '0', STR_PAD_LEFT);
}