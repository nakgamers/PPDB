<?php

namespace App\Models;

use CodeIgniter\Model;

class PembayaranDetailModel extends Model
{
    protected $table = 'pembayaran_detail';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'pembayaran_siswa_id',
        'total_sebelum_diskon',
        'total_diskon',
        'total_setelah_diskon',
        'jumlah_bayar',
        'sisa_bayar',
        'status_pembayaran'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getDetailPembayaran($pembayaran_siswa_id)
    {
        return $this->where('pembayaran_siswa_id', $pembayaran_siswa_id)->first();
    }
}