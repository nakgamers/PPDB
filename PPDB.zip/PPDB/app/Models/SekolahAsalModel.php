<?php

namespace App\Models;

use CodeIgniter\Model;

class SekolahAsalModel extends Model
{
    protected $table            = 'sekolah_asal';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['nama_sekolah', 'alamat'];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
}