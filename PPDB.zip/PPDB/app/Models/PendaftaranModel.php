<?php

namespace App\Models;

use CodeIgniter\Model;

class PendaftaranModel extends Model
{
    protected $table = 'pendaftaran';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = [
        'no_pendaftaran', 'nama_lengkap', 'jenis_kelamin', 
        'tempat_lahir', 'tanggal_lahir', 'sekolah_asal_id',
        'jurusan_id_1', 'jurusan_id_2', 'no_hp', 'nama_ortu',
        'alamat', 'kip_kks_pkh', 'jenis_formulir'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Add validation rules to match database constraints
    protected $validationRules = [
        'no_pendaftaran' => 'permit_empty|max_length[20]',
        'nama_lengkap' => 'permit_empty|max_length[100]',
        'jenis_kelamin' => 'permit_empty|in_list[L,P]',
        'tempat_lahir' => 'permit_empty|max_length[100]',
        'tanggal_lahir' => 'permit_empty|valid_date',
        'sekolah_asal_id' => 'permit_empty|integer',
        'jurusan_id_1' => 'permit_empty|integer',
        'jurusan_id_2' => 'permit_empty|integer',
        'no_hp' => 'permit_empty|max_length[15]',
        'nama_ortu' => 'permit_empty|max_length[100]',
        'alamat' => 'permit_empty',
        'kip_kks_pkh' => 'permit_empty|in_list[Ya,Tidak]'
    ];

    public function getWithRelations()
    {
        return $this->select('pendaftaran.*, 
                            j1.nama_jurusan as jurusan_1,
                            j2.nama_jurusan as jurusan_2,
                            sekolah_asal.nama_sekolah')
                    ->join('jurusan as j1', 'j1.id = pendaftaran.jurusan_id_1')
                    ->join('jurusan as j2', 'j2.id = pendaftaran.jurusan_id_2', 'left')
                    ->join('sekolah_asal', 'sekolah_asal.id = pendaftaran.sekolah_asal_id')
                    ->findAll();
    }

    public function getPendaftaranDetail($id)
    {
        $builder = $this->db->table('pendaftaran p');
        $builder->select('p.*, j.nama_jurusan, sa.nama_sekolah')
                ->join('jurusan j', 'j.id = p.jurusan_id_1')
                ->join('sekolah_asal sa', 'sa.id = p.sekolah_asal_id')
                ->where('p.id', $id);
        
        return $builder->get()->getRowArray();
    }
}