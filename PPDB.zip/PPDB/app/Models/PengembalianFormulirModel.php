<?php

namespace App\Models;

use CodeIgniter\Model;

class PengembalianFormulirModel extends Model
{
    protected $table            = 'pengembalian_formulir';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['pendaftaran_id', 'tanggal_pengembalian', 'status', 'created_at', 'updated_at'];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules = [
        'pendaftaran_id'       => 'required|numeric',
        'tanggal_pengembalian' => 'required|valid_date',
        'status'               => 'required|in_list[Lengkap,Belum Lengkap]'
    ];
}