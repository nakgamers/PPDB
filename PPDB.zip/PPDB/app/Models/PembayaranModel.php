<?php

namespace App\Models;

use CodeIgniter\Model;

class PembayaranModel extends Model
{
    protected $table = 'pembayaran';
    protected $primaryKey = 'id';
    protected $allowedFields = ['jurusan_id', 'nama_pembayaran', 'jumlah'];

    public function getWithJurusan()
    {
        return $this->select('pembayaran.*, jurusan.nama_jurusan')
                    ->join('jurusan', 'jurusan.id = pembayaran.jurusan_id')
                    ->findAll();
    }
}