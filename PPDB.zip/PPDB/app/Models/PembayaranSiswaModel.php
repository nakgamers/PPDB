<?php

namespace App\Models;

use CodeIgniter\Model;

class PembayaranSiswaModel extends Model
{
    protected $table = 'pembayaran_siswa';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'pendaftaran_id', 
        'pembayaran_id', 
        'jumlah_bayar',
        'diskon_id',  // Add this line
        'tanggal_bayar'
    ];

    public function getWithRelations()
    {
        return $this->select('pembayaran_siswa.*, pendaftaran.nama_lengkap, pembayaran.nama_pembayaran, pembayaran.jumlah')
                    ->join('pendaftaran', 'pendaftaran.id = pembayaran_siswa.pendaftaran_id')
                    ->join('pembayaran', 'pembayaran.id = pembayaran_siswa.pembayaran_id')
                    ->findAll();
    }
}