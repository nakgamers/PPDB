<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Auth::index');
$routes->get('login', 'Auth::index');
$routes->post('login', 'Auth::login');
$routes->get('logout', 'Auth::logout');
$routes->get('dashboard', 'Dashboard::index');

// Jurusan Routes
$routes->get('jurusan', 'Jurusan::index');
$routes->get('jurusan/create', 'Jurusan::create');
$routes->post('jurusan/store', 'Jurusan::store');
$routes->get('jurusan/edit/(:num)', 'Jurusan::edit/$1');
$routes->post('jurusan/update/(:num)', 'Jurusan::update/$1');
$routes->get('jurusan/delete/(:num)', 'Jurusan::delete/$1');

// Sekolah Asal Routes
$routes->get('sekolah-asal', 'SekolahAsal::index');
$routes->get('sekolah-asal/create', 'SekolahAsal::create');
$routes->post('sekolah-asal/store', 'SekolahAsal::store');
$routes->get('sekolah-asal/edit/(:num)', 'SekolahAsal::edit/$1');
$routes->post('sekolah-asal/update/(:num)', 'SekolahAsal::update/$1');
$routes->get('sekolah-asal/delete/(:num)', 'SekolahAsal::delete/$1');

// Pendaftaran Routes
$routes->get('pendaftaran', 'Pendaftaran::index');
$routes->get('pendaftaran/create', 'Pendaftaran::create');
$routes->post('pendaftaran/store', 'Pendaftaran::store');
$routes->get('pendaftaran/edit/(:num)', 'Pendaftaran::edit/$1');
$routes->post('pendaftaran/update/(:num)', 'Pendaftaran::update/$1');
$routes->get('pendaftaran/delete/(:num)', 'Pendaftaran::delete/$1');
$routes->get('pendaftaran/check-number/(:num)', 'Pendaftaran::checkNumber/$1');
$routes->post('pendaftaran/store', 'Pendaftaran::store');

// Pembayaran Routes
$routes->get('pembayaran', 'Pembayaran::index');
$routes->get('pembayaran/create', 'Pembayaran::create');
$routes->post('pembayaran/store', 'Pembayaran::store');
$routes->get('pembayaran/edit/(:num)', 'Pembayaran::edit/$1');
$routes->post('pembayaran/update/(:num)', 'Pembayaran::update/$1');
$routes->get('pembayaran/delete/(:num)', 'Pembayaran::delete/$1');
$routes->get('pembayaran/getJurusanPayments/(:num)', 'Pembayaran::getJurusanPayments/$1');
$routes->get('pembayaran-siswa', 'PembayaranSiswa::index');
$routes->get('pembayaran-siswa/create', 'PembayaranSiswa::create');
$routes->post('pembayaran-siswa/store', 'PembayaranSiswa::store');
$routes->get('pembayaran-siswa/edit/(:num)', 'PembayaranSiswa::edit/$1');
$routes->post('pembayaran-siswa/update/(:num)', 'PembayaranSiswa::update/$1');
$routes->get('pembayaran-siswa/detail/(:num)', 'PembayaranSiswa::detail/$1');
$routes->post('pembayaran-siswa/process', 'PembayaranSiswa::process');
$routes->get('pembayaran-siswa/delete/(:num)', 'PembayaranSiswa::delete/$1');
$routes->get('pembayaran-siswa/getPembayaranByJurusan/(:num)', 'PembayaranSiswa::getPembayaranByJurusan/$1');
$routes->get('pembayaran-siswa/pelunasan/(:num)', 'PembayaranSiswa::pelunasan/$1');
$routes->post('pembayaran-siswa/process-pelunasan', 'PembayaranSiswa::processPelunasan');
$routes->get('diskon', 'Diskon::index');
$routes->get('diskon/create', 'Diskon::create');
$routes->post('diskon/store', 'Diskon::store');
$routes->get('diskon/edit/(:num)', 'Diskon::edit/$1');
$routes->post('diskon/update/(:num)', 'Diskon::update/$1');
$routes->get('diskon/delete/(:num)', 'Diskon::delete/$1');

// Pengembalian Formulir Routes
$routes->get('pengembalian-formulir', 'PengembalianFormulir::index');
$routes->get('pengembalian-formulir/create', 'PengembalianFormulir::create');
$routes->post('pengembalian-formulir/store', 'PengembalianFormulir::store');
$routes->get('pengembalian-formulir/edit/(:num)', 'PengembalianFormulir::edit/$1');
$routes->post('pengembalian-formulir/update/(:num)', 'PengembalianFormulir::update/$1');
$routes->get('pengembalian-formulir/delete/(:num)', 'PengembalianFormulir::delete/$1');
$routes->get('pengembalian-formulir/detail/(:num)', 'PengembalianFormulir::detail/$1');

// Report Routes
$routes->get('laporan/statistik-siswa', 'Laporan::statistikSiswa');
$routes->get('laporan/keuangan', 'Laporan::keuangan');
$routes->get('laporan/data-siswa', 'Laporan::dataSiswa');
