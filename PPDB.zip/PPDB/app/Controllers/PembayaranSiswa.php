<?php

namespace App\Controllers;

use App\Models\PembayaranSiswaModel;
use App\Models\PendaftaranModel;
use App\Models\PembayaranModel;

class PembayaranSiswa extends BaseController
{
    protected $pembayaranSiswaModel;
    protected $pendaftaranModel;
    protected $pembayaranModel;
    protected $db; // Add this line

    public function __construct()
    {
        $this->pembayaranSiswaModel = new PembayaranSiswaModel();
        $this->pendaftaranModel = new PendaftaranModel();
        $this->pembayaranModel = new PembayaranModel();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pembayaran_siswa ps');
        $builder->select('pd.*, p.nama_lengkap, p.nama_ortu, ps.status, ps.tanggal_bayar')
                ->join('pembayaran_detail pd', 'ps.id = pd.pembayaran_siswa_id')
                ->join('pendaftaran p', 'p.id = ps.pendaftaran_id')
                ->orderBy('pd.created_at', 'DESC');
        
        $data['pembayaran_detail'] = $builder->get()->getResultArray();
        return view('pembayaran_siswa/index', $data);
    }

    public function create()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pendaftaran p');
        $builder->select('p.*, j.nama_jurusan')
                ->join('jurusan j', 'j.id = p.jurusan_id_1')
                ->join('pengembalian_formulir pf', 'pf.pendaftaran_id = p.id')
                ->where('pf.status', 'Lengkap');

        // Add filters
        $no_pendaftaran = $this->request->getGet('no_pendaftaran');
        $nama_siswa = $this->request->getGet('nama_siswa');
        $jurusan = $this->request->getGet('jurusan');
    
        if ($no_pendaftaran) {
            $builder->like('p.no_pendaftaran', $no_pendaftaran);
        }
        if ($nama_siswa) {
            $builder->like('p.nama_lengkap', $nama_siswa);
        }
        if ($jurusan) {
            $builder->where('j.id', $jurusan);
        }
    
        $data['pendaftaran'] = $builder->get()->getResultArray();
        $data['jurusan_list'] = $db->table('jurusan')->get()->getResultArray();
        $data['pembayaran'] = $db->table('pembayaran')->get()->getResultArray();
        $data['request'] = $this->request;
    
        return view('pembayaran_siswa/create', $data);
    }

    public function getPembayaranByJurusan($jurusanId)
    {
        $pembayaran = $this->pembayaranModel->where('jurusan_id', $jurusanId)->findAll();
        return $this->response->setJSON($pembayaran);
    }

    public function store()
    {
        $pendaftaran_id = $this->request->getPost('pendaftaran_id');
        $pembayaran_ids = $this->request->getPost('pembayaran_id');
        $jumlah_bayar = $this->request->getPost('jumlah_bayar');
        $diskon_id = $this->request->getPost('diskon_id');

        // Insert each payment separately
        foreach ($pembayaran_ids as $pembayaran_id) {
            $data = [
                'pendaftaran_id' => $pendaftaran_id,
                'pembayaran_id' => $pembayaran_id,
                'jumlah_bayar' => $jumlah_bayar,
                'diskon_id' => $diskon_id,
                'tanggal_bayar' => date('Y-m-d'),
                'status' => 'lunas'
            ];

            $this->pembayaranSiswaModel->insert($data);
        }

        return redirect()->to('pembayaran-siswa')->with('success', 'Pembayaran berhasil diproses');
    }

    public function edit($id)
    {
        $data['pembayaran_siswa'] = $this->pembayaranSiswaModel->find($id);
        $data['pendaftaran'] = $this->pendaftaranModel->findAll();
        $data['pembayaran'] = $this->pembayaranModel->findAll();
        return view('pembayaran_siswa/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'pendaftaran_id' => $this->request->getPost('pendaftaran_id'),
            'pembayaran_id' => $this->request->getPost('pembayaran_id'),
            'status' => $this->request->getPost('status'),
            'tanggal_bayar' => $this->request->getPost('tanggal_bayar') ?: null
        ];

        $this->pembayaranSiswaModel->update($id, $data);
        return redirect()->to('pembayaran-siswa')->with('success', 'Data pembayaran siswa berhasil diupdate');
    }

    public function delete($id)
    {
        $db = \Config\Database::connect();
        
        try {
            $db->transStart();
            
            // Get pembayaran_siswa_id from pembayaran_detail
            $pembayaranDetail = $db->table('pembayaran_detail')
                                ->where('id', $id)
                                ->get()
                                ->getRowArray();
                                
            if ($pembayaranDetail) {
                // Delete from pembayaran_detail first (child table)
                $db->table('pembayaran_detail')
                   ->where('id', $id)
                   ->delete();
                
                // Then delete from pembayaran_siswa (parent table)
                $db->table('pembayaran_siswa')
                   ->where('id', $pembayaranDetail['pembayaran_siswa_id'])
                   ->delete();
            }
            
            $db->transComplete();
            
            if ($db->transStatus() === false) {
                return redirect()->back()->with('error', 'Gagal menghapus data pembayaran');
            }
            
            return redirect()->to('pembayaran-siswa')->with('success', 'Data pembayaran berhasil dihapus');
            
        } catch (\Exception $e) {
            $db->transRollback();
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function detail($id)
    {
        $pendaftaranModel = new \App\Models\PendaftaranModel();
        $pembayaranModel = new \App\Models\PembayaranModel();
        $diskonModel = new \App\Models\DiskonModel();

        $siswa = $pendaftaranModel->select('pendaftaran.*, jurusan.nama_jurusan')
                                 ->join('jurusan', 'jurusan.id = pendaftaran.jurusan_id_1')
                                 ->find($id);

        return view('pembayaran_siswa/detail_pembayaran', [
            'siswa' => $siswa,
            'pembayaran' => $pembayaranModel->where('jurusan_id', $siswa['jurusan_id_1'])->findAll(),
            'diskon' => $diskonModel->where('status', 'aktif')->findAll()
        ]);
    }

    public function process()
        {
            $this->db->transStart();

            try {
                // 1. First insert into pembayaran_siswa
                $pendaftaran_id = $this->request->getPost('pendaftaran_id');
                $pembayaran_ids = $this->request->getPost('pembayaran_id');
                $diskon_id = $this->request->getPost('diskon_id');

                $pembayaranSiswaData = [
                    'pendaftaran_id' => $pendaftaran_id,
                    'pembayaran_id' => $pembayaran_ids[0], // Using first payment ID
                    'diskon_id' => $diskon_id,
                    'tanggal_bayar' => date('Y-m-d'),
                    'status' => 'lunas'
                ];
                
                // Insert and get the ID
                $pembayaran_siswa_id = $this->pembayaranSiswaModel->insert($pembayaranSiswaData, true);

                // 2. Then insert pembayaran_detail with the pembayaran_siswa_id
                $pembayaranDetailData = [
                    'pembayaran_siswa_id' => $pembayaran_siswa_id,
                    'total_sebelum_diskon' => $this->request->getPost('total_sebelum_diskon'),
                    'total_diskon' => $this->request->getPost('total_diskon'),
                    'total_setelah_diskon' => $this->request->getPost('total_setelah_diskon'),
                    'jumlah_bayar' => $this->request->getPost('jumlah_bayar'),
                    'sisa_bayar' => $this->request->getPost('sisa_bayar')
                ];
                
                $pembayaranDetailModel = new \App\Models\PembayaranDetailModel();
                $pembayaranDetailModel->insert($pembayaranDetailData);

                $this->db->transCommit();
                return redirect()->to('pembayaran-siswa')->with('success', 'Pembayaran berhasil diproses');

            } catch (\Exception $e) {
                $this->db->transRollback();
                return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
            }
        }

    public function pelunasan($id)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pembayaran_detail pd');
        $builder->select('pd.*, p.nama_lengkap, p.no_pendaftaran, j.nama_jurusan')
                ->join('pembayaran_siswa ps', 'ps.id = pd.pembayaran_siswa_id')
                ->join('pendaftaran p', 'p.id = ps.pendaftaran_id')
                ->join('jurusan j', 'j.id = p.jurusan_id_1')
                ->where('pd.id', $id);
        
        $result = $builder->get()->getRowArray();
        
        $data = [
            'pembayaran_detail' => $result,
            'siswa' => [
                'nama_lengkap' => $result['nama_lengkap'],
                'no_pendaftaran' => $result['no_pendaftaran'],
                'nama_jurusan' => $result['nama_jurusan']
            ]
        ];
        
        return view('pembayaran_siswa/pelunasan', $data);
    }

    public function processPelunasan()
    {
        $db = \Config\Database::connect();
        
        try {
            $db->transStart();
            
            $id = $this->request->getPost('pembayaran_detail_id');
            $jumlahBayar = $this->request->getPost('jumlah_bayar');
            
            // Get current payment detail
            $pembayaranDetail = $db->table('pembayaran_detail')
                                ->where('id', $id)
                                ->get()
                                ->getRowArray();
            
            // Update payment detail
            $newJumlahBayar = $pembayaranDetail['jumlah_bayar'] + $jumlahBayar;
            $newSisaBayar = $pembayaranDetail['total_setelah_diskon'] - $newJumlahBayar;
            
            $db->table('pembayaran_detail')
               ->where('id', $id)
               ->update([
                   'jumlah_bayar' => $newJumlahBayar,
                   'sisa_bayar' => $newSisaBayar,
                   'updated_at' => date('Y-m-d H:i:s')
               ]);
            
            $db->transComplete();
            
            if ($db->transStatus() === false) {
                return redirect()->back()->with('error', 'Gagal memproses pelunasan');
            }
            
            return redirect()->to('pembayaran-siswa')->with('success', 'Pelunasan berhasil diproses');
            
        } catch (\Exception $e) {
            $db->transRollback();
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
}