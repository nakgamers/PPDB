<?php

namespace App\Controllers;

use App\Models\JurusanModel;

class Jurusan extends BaseController
{
    protected $jurusanModel;

    public function __construct()
    {
        $this->jurusanModel = new JurusanModel();
    }

    public function index()
    {
        $data['jurusan'] = $this->jurusanModel->findAll();
        return view('jurusan/index', $data);
    }

    public function create()
    {
        return view('jurusan/create');
    }

    public function store()
    {
        $data = [
            'nama_jurusan' => $this->request->getPost('nama_jurusan'),
            'detail_jurusan' => $this->request->getPost('detail_jurusan'),
            'harga_spp' => null,
        ];

        // Handle file upload and continue with existing store logic
    }

    public function edit($id)
    {
        $data['jurusan'] = $this->jurusanModel->find($id);
        return view('jurusan/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'nama_jurusan' => $this->request->getPost('nama_jurusan'),
            'detail_jurusan' => $this->request->getPost('detail_jurusan'),
            'harga_spp' => null, // Set harga_spp to null
        ];

        $foto = $this->request->getFile('foto_jurusan');
        if ($foto->isValid() && !$foto->hasMoved()) {
            $fileName = $foto->getRandomName();
            $foto->move('uploads/jurusan', $fileName);
            $data['foto_jurusan'] = $fileName;
        }

        $this->jurusanModel->update($id, $data);
        return redirect()->to('jurusan')->with('success', 'Jurusan updated successfully');
    }

    public function delete($id)
    {
        $this->jurusanModel->delete($id);
        return redirect()->to('jurusan')->with('success', 'Jurusan deleted successfully');
    }
}