<?php

namespace App\Controllers;

class Diskon extends BaseController
{
    protected $diskonModel;

    public function __construct()
    {
        $this->diskonModel = new \App\Models\DiskonModel();
    }

    public function index()
    {
        return view('diskon/index', [
            'diskon' => $this->diskonModel->findAll()
        ]);
    }

    public function create()
    {
        return view('diskon/create');
    }

    public function store()
    {
        $data = [
            'nama_diskon' => $this->request->getPost('nama_diskon'),
            'jumlah_diskon' => (float)str_replace(['.',','], '', $this->request->getPost('jumlah_diskon')),
            'tipe_diskon' => $this->request->getPost('tipe_diskon'),
            'status' => $this->request->getPost('status') ?? 'aktif'
        ];

        $this->diskonModel->insert($data);
        return redirect()->to('diskon')->with('success', 'Diskon berhasil ditambahkan');
    }

    public function edit($id)
    {
        return view('diskon/edit', [
            'diskon' => $this->diskonModel->find($id)
        ]);
    }

    public function update($id)
    {
        $data = [
            'nama_diskon' => $this->request->getPost('nama_diskon'),
            'jumlah_diskon' => (float)str_replace(['.',','], '', $this->request->getPost('jumlah_diskon')),
            'tipe_diskon' => $this->request->getPost('tipe_diskon'),
            'status' => $this->request->getPost('status') ?? 'aktif'
        ];

        $this->diskonModel->update($id, $data);
        return redirect()->to('diskon')->with('success', 'Diskon berhasil diupdate');
    }

    public function delete($id)
    {
        $this->diskonModel->delete($id);
        return redirect()->to('diskon')->with('success', 'Diskon berhasil dihapus');
    }
}