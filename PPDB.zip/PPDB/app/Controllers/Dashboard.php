<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        // Get total counts
        $data['total_pendaftar'] = $this->db->table('pendaftaran')->countAllResults();
        $data['total_pengembalian'] = $this->db->table('pengembalian_formulir')->countAllResults();
        $data['total_jurusan'] = $this->db->table('jurusan')->countAllResults();
        
        // Calculate total payments
        $data['total_pembayaran'] = $this->db->table('pembayaran_detail')
            ->selectSum('jumlah_bayar')
            ->get()
            ->getRow()
            ->jumlah_bayar ?? 0;
        
        // Get statistics per jurusan
        $jurusanStats = $this->db->table('pendaftaran p')
            ->select('j.nama_jurusan, COUNT(*) as total')
            ->join('jurusan j', 'j.id = p.jurusan_id_1')
            ->groupBy('j.nama_jurusan')
            ->get()
            ->getResultArray();
        
        $data['jurusan_labels'] = array_column($jurusanStats, 'nama_jurusan');
        $data['jurusan_data'] = array_column($jurusanStats, 'total');
        
        // Get form return status statistics
        $data['status_data'] = [
            $this->db->table('pengembalian_formulir')->where('status', 'Lengkap')->countAllResults(),
            $this->db->table('pengembalian_formulir')->where('status', 'Belum Lengkap')->countAllResults()
        ];
        
        // Get recent activities
        $data['recent_activities'] = $this->db->table('pengembalian_formulir pf')
            ->select('pf.*, p.no_pendaftaran, p.nama_lengkap, j.nama_jurusan')
            ->join('pendaftaran p', 'p.id = pf.pendaftaran_id')
            ->join('jurusan j', 'j.id = p.jurusan_id_1')
            ->orderBy('pf.created_at', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();
        
        // Get top 5 schools
        $builder = $this->db->table('pendaftaran p')
            ->select('sa.nama_sekolah, COUNT(*) as total_siswa')
            ->join('sekolah_asal sa', 'sa.id = p.sekolah_asal_id')
            ->groupBy('sa.nama_sekolah')
            ->orderBy('total_siswa', 'DESC')
            ->limit(5);
        
        $query = $builder->get();
        $top_schools = $query->getResultArray();
        
        $data['sekolah_labels'] = array_column($top_schools, 'nama_sekolah');
        $data['sekolah_data'] = array_column($top_schools, 'total_siswa');
        return view('dashboard/index', $data);
    }
}