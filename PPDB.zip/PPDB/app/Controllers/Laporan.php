<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Laporan extends BaseController
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function statistikSiswa()
    {
        // Statistics based on various criteria
        $data['per_jurusan'] = $this->db->table('pendaftaran p')
            ->select('j.nama_jurusan, COUNT(*) as total')
            ->join('jurusan j', 'j.id = p.jurusan_id_1')
            ->groupBy('j.nama_jurusan')
            ->get()
            ->getResultArray();

        $data['per_sekolah'] = $this->db->table('pendaftaran p')
            ->select('sa.nama_sekolah, COUNT(*) as total')
            ->join('sekolah_asal sa', 'sa.id = p.sekolah_asal_id')
            ->groupBy('sa.nama_sekolah')
            ->orderBy('total', 'DESC')
            ->get()
            ->getResultArray();

        $data['status_formulir'] = [
            'lengkap' => $this->db->table('pengembalian_formulir')->where('status', 'Lengkap')->countAllResults(),
            'belum_lengkap' => $this->db->table('pengembalian_formulir')->where('status', 'Belum Lengkap')->countAllResults()
        ];

        return view('laporan/statistik_siswa', $data);
    }

    public function keuangan()
    {
        // Get financial summary
        $data['total_pemasukan'] = $this->db->table('pembayaran_detail')
            ->selectSum('jumlah_bayar')
            ->get()
            ->getRow()
            ->jumlah_bayar ?? 0;

        // Get detailed payment records
        $data['pembayaran_detail'] = $this->db->table('pembayaran_detail pd')
            ->select('pd.*, p.nama_pembayaran, pf.nama_lengkap, pf.no_pendaftaran')
            ->join('pembayaran_siswa ps', 'ps.id = pd.pembayaran_siswa_id')
            ->join('pembayaran p', 'p.id = ps.pembayaran_id')
            ->join('pendaftaran pf', 'pf.id = ps.pendaftaran_id')
            ->orderBy('pd.created_at', 'DESC')
            ->get()
            ->getResultArray();

        // Get payment summary by type
        $data['summary_per_jenis'] = $this->db->table('pembayaran_detail pd')
            ->select('p.nama_pembayaran, SUM(pd.jumlah_bayar) as total')
            ->join('pembayaran_siswa ps', 'ps.id = pd.pembayaran_siswa_id')
            ->join('pembayaran p', 'p.id = ps.pembayaran_id')
            ->groupBy('p.nama_pembayaran')
            ->get()
            ->getResultArray();

        return view('laporan/keuangan', $data);
    }

    public function dataSiswa()
    {
        $data['siswa'] = $this->db->table('pendaftaran p')
            ->select('p.*, j.nama_jurusan, sa.nama_sekolah, 
                     p.nama_ortu,
                     pf.status as status_formulir,
                     COALESCE(SUM(pd.jumlah_bayar), 0) as total_bayar,
                     pb.jumlah as total_harus_bayar')
            ->join('jurusan j', 'j.id = p.jurusan_id_1')
            ->join('sekolah_asal sa', 'sa.id = p.sekolah_asal_id')
            ->join('pembayaran_siswa ps', 'ps.pendaftaran_id = p.id', 'left')
            ->join('pembayaran pb', 'pb.id = ps.pembayaran_id', 'left')
            ->join('pembayaran_detail pd', 'pd.pembayaran_siswa_id = ps.id', 'left')
            ->join('pengembalian_formulir pf', 'pf.pendaftaran_id = p.id', 'left')
            ->groupBy('p.id')
            ->get()
            ->getResultArray();

        return view('laporan/data_siswa', $data);
    }
}