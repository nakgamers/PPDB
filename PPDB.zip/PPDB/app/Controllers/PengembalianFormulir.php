<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PendaftaranModel;

class PengembalianFormulir extends BaseController
{
    protected $pengembalianFormulirModel;
    protected $pendaftaranModel;

    public function __construct()
    {
        $this->pengembalianFormulirModel = new \App\Models\PengembalianFormulirModel();
        $this->pendaftaranModel = new \App\Models\PendaftaranModel();
    }

    public function index()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pengembalian_formulir pf');
        $builder->select('pf.*, p.no_pendaftaran, p.nama_lengkap, p.nama_ortu')
                ->join('pendaftaran p', 'p.id = pf.pendaftaran_id');
        
        $data['pengembalian_formulir'] = $builder->get()->getResultArray();
        
        return view('pengembalian_formulir/index', $data);
    }

    public function create()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pendaftaran p');
        $builder->select('p.*, j.nama_jurusan')
                ->join('jurusan j', 'j.id = p.jurusan_id_1');

        // Add filters
        $nama = $this->request->getGet('nama');
        $jurusan = $this->request->getGet('jurusan');

        if ($nama) {
            $builder->like('p.nama_lengkap', $nama);
        }
        if ($jurusan) {
            $builder->where('j.id', $jurusan);
        }
        
        $data['pendaftaran'] = $builder->get()->getResultArray();
        $data['jurusan'] = $db->table('jurusan')->get()->getResultArray();
        return view('pengembalian_formulir/create', $data);
    }

    public function store()
    {
        $data = [
            'pendaftaran_id' => $this->request->getPost('pendaftaran_id'),
            'tanggal_pengembalian' => $this->request->getPost('tanggal_pengembalian'),
            'status' => $this->request->getPost('status'),
            'no_formulir' => generate_no_formulir(),
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->pengembalianFormulirModel->insert($data);
        return redirect()->to('pengembalian-formulir')->with('success', 'Data berhasil ditambahkan');
    }

    public function edit($id)
    {
        $data['pengembalian_formulir'] = $this->pengembalianFormulirModel->find($id);
        $data['pendaftaran'] = $this->pendaftaranModel->findAll();
        return view('pengembalian_formulir/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'pendaftaran_id' => $this->request->getPost('pendaftaran_id'),
            'tanggal_pengembalian' => $this->request->getPost('tanggal_pengembalian'),
            'status' => $this->request->getPost('status'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->pengembalianFormulirModel->update($id, $data);
        return redirect()->to('pengembalian-formulir')->with('success', 'Data berhasil diupdate');
    }

    public function delete($id)
    {
        $this->pengembalianFormulirModel->delete($id);
        return redirect()->to('pengembalian-formulir')->with('success', 'Data berhasil dihapus');
    }

    public function detail($id)
    {
        $data['pendaftaran'] = $this->pendaftaranModel->getPendaftaranDetail($id);
        $data['no_formulir'] = $this->generateNoFormulir();
        
        return view('pengembalian_formulir/detail', $data);
    }

    private function generateNoFormulir()
    {
        $prefix = 'FORM';
        $year = date('Y');
        $month = date('m');
        
        // Get the last number from database
        $db = \Config\Database::connect();
        $builder = $db->table('pengembalian_formulir');
        $builder->selectMax('id');
        $query = $builder->get();
        $lastId = $query->getRowArray()['id'] ?? 0;
        $nextId = $lastId + 1;
        
        // Format: FORM-YYYY-MM-XXXX
        return sprintf("%s-%s-%s-%04d", $prefix, $year, $month, $nextId);
    }
}