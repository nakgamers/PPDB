<?php

namespace App\Controllers;

use App\Models\PendaftaranModel;
use App\Models\JurusanModel;
use App\Models\SekolahAsalModel;

class Pendaftaran extends BaseController
{
    protected $pendaftaranModel;
    protected $jurusanModel;
    protected $sekolahAsalModel;

    public function __construct()
    {
        $this->pendaftaranModel = new PendaftaranModel();
        $this->jurusanModel = new JurusanModel();
        $this->sekolahAsalModel = new SekolahAsalModel();
    }

    public function index()
    {
        $data['pendaftaran'] = $this->pendaftaranModel->getWithRelations();
        return view('pendaftaran/index', $data);
    }

    public function create()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pendaftaran');
        $total = $builder->countAllResults();
        $nomor_baru = $total + 1;
        
        $data = [
            'nomor_pendaftaran' => str_pad($nomor_baru, 4, '0', STR_PAD_LEFT),
            'sekolah' => $this->sekolahAsalModel->findAll(), // Fixed model name
            'jurusan' => $this->jurusanModel->findAll()
        ];
        
        return view('pendaftaran/create', $data);
    }

    public function store()
    {
        $data = [
            'no_pendaftaran' => $this->request->getPost('no_pendaftaran'),
            'nama_lengkap' => $this->request->getPost('nama_lengkap'),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'sekolah_asal_id' => $this->request->getPost('sekolah_asal_id'),
            'jurusan_id_1' => $this->request->getPost('jurusan_id_1'),
            'jurusan_id_2' => $this->request->getPost('jurusan_id_2') ?: null,
            'no_hp' => $this->request->getPost('no_hp'),
            'nama_ortu' => $this->request->getPost('nama_ortu'),
            'alamat' => $this->request->getPost('alamat'),
            'kip_kks_pkh' => $this->request->getPost('kip_kks_pkh'),
            'jenis_formulir' => $this->request->getPost('jenis_formulir')
        ];
    
        try {
            if (!$this->pendaftaranModel->insert($data)) {
                $errors = $this->pendaftaranModel->errors();
                log_message('error', 'Validation errors: ' . print_r($errors, true));
                return redirect()->back()
                    ->with('error', 'Validasi gagal: ' . implode(', ', $errors))
                    ->withInput();
            }
            
            return redirect()->to(base_url('pendaftaran'))
                ->with('success', 'Pendaftaran berhasil disimpan');
        } catch (\Exception $e) {
            log_message('error', '[Pendaftaran Store] ' . $e->getMessage());
            return redirect()->back()
                ->with('error', 'Terjadi kesalahan: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function edit($id)
    {
        $data['pendaftaran'] = $this->pendaftaranModel->find($id);
        $data['jurusan'] = $this->jurusanModel->findAll();
        $data['sekolah'] = $this->sekolahAsalModel->findAll();
        return view('pendaftaran/edit', $data);
    }

    public function update($id)
    {
        $this->pendaftaranModel->update($id, [
            'nama_lengkap' => $this->request->getPost('nama_lengkap'),
            'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
            'tempat_lahir' => $this->request->getPost('tempat_lahir'),
            'tanggal_lahir' => $this->request->getPost('tanggal_lahir'),
            'sekolah_asal_id' => $this->request->getPost('sekolah_asal_id'),
            'jurusan_id_1' => $this->request->getPost('jurusan_id_1'),
            'jurusan_id_2' => $this->request->getPost('jurusan_id_2'),
            'no_hp' => $this->request->getPost('no_hp'),
            'nama_ortu' => $this->request->getPost('nama_ortu'),
            'alamat' => $this->request->getPost('alamat'),
            'kip_kks_pkh' => $this->request->getPost('kip_kks_pkh'),
            'jenis_formulir' => $this->request->getPost('jenis_formulir')
        ]);

        return redirect()->to('pendaftaran')->with('success', 'Data pendaftaran berhasil diupdate');
    }

    public function delete($id)
    {
        $this->pendaftaranModel->delete($id);
        return redirect()->to('pendaftaran')->with('success', 'Data pendaftaran berhasil dihapus');
    }

    public function checkNumber($number)
    {
        $exists = $this->pendaftaranModel->where('no_pendaftaran', $number)->first() !== null;
        return $this->response->setJSON(['exists' => $exists]);
    }
}