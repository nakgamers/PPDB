<?php

namespace App\Controllers;

use App\Models\PembayaranModel;
use App\Models\JurusanModel;

class Pembayaran extends BaseController
{
    protected $pembayaranModel;
    protected $jurusanModel;

    public function __construct()
    {
        $this->pembayaranModel = new PembayaranModel();
        $this->jurusanModel = new JurusanModel();
    }

    public function index()
    {
        $data['pembayaran'] = $this->pembayaranModel->getWithJurusan();
        return view('pembayaran/index', $data);
    }

    public function create()
    {
        $data['jurusan'] = $this->jurusanModel->findAll();
        return view('pembayaran/create', $data);
    }

    public function store()
    {
        $jurusan_id = $this->request->getPost('jurusan_id');
        $nama_pembayaran = $this->request->getPost('nama_pembayaran');
        $jumlah = $this->request->getPost('jumlah');

        // Process each payment type
        foreach ($nama_pembayaran as $index => $nama) {
            if (!empty($jumlah[$index])) {
                // Check if payment record already exists
                $existing = $this->pembayaranModel->where([
                    'jurusan_id' => $jurusan_id,
                    'nama_pembayaran' => $nama
                ])->first();

                $data = [
                    'jurusan_id' => $jurusan_id,
                    'nama_pembayaran' => $nama,
                    'jumlah' => (int)str_replace(['.',','], '', $jumlah[$index])
                ];

                if ($existing) {
                    // Update existing record
                    $this->pembayaranModel->update($existing['id'], $data);
                } else {
                    // Insert new record
                    $this->pembayaranModel->insert($data);
                }
            }
        }

        return redirect()->to('pembayaran')->with('success', 'Data pembayaran berhasil disimpan');
    }

    public function edit($id)
    {
        $data['pembayaran'] = $this->pembayaranModel->find($id);
        $data['jurusan'] = $this->jurusanModel->findAll();
        return view('pembayaran/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'jurusan_id' => $this->request->getPost('jurusan_id'),
            'nama_pembayaran' => $this->request->getPost('nama_pembayaran'),
            'jumlah' => str_replace(['.', ','], '', $this->request->getPost('jumlah'))
        ];

        $this->pembayaranModel->update($id, $data);
        return redirect()->to('pembayaran')->with('success', 'Data pembayaran berhasil diupdate');
    }

    public function delete($id)
    {
        $this->pembayaranModel->delete($id);
        return redirect()->to('pembayaran')->with('success', 'Data pembayaran berhasil dihapus');
    }

    public function getJurusanPayments($jurusanId)
        {
            $payments = $this->pembayaranModel->where('jurusan_id', $jurusanId)->findAll();
            return $this->response->setJSON($payments);
        }
}