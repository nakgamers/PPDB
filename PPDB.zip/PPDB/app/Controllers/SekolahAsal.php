<?php

namespace App\Controllers;

use App\Models\SekolahAsalModel;

class SekolahAsal extends BaseController
{
    protected $sekolahAsalModel;

    public function __construct()
    {
        $this->sekolahAsalModel = new SekolahAsalModel();
    }

    public function index()
    {
        $data['sekolah'] = $this->sekolahAsalModel->findAll();
        return view('sekolah_asal/index', $data);
    }

    public function create()
    {
        return view('sekolah_asal/create');
    }

    public function store()
    {
        $data = [
            'nama_sekolah' => $this->request->getPost('nama_sekolah'),
            'alamat' => $this->request->getPost('alamat')
        ];
        
        try {
            $this->sekolahAsalModel->insert($data);
            $school = $this->sekolahAsalModel->find($this->sekolahAsalModel->getInsertID());
            
            return $this->response->setJSON([
                'success' => true,
                'school' => $school
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Gagal menyimpan data sekolah'
            ]);
        }
    }

    public function edit($id)
    {
        $data['sekolah'] = $this->sekolahAsalModel->find($id);
        return view('sekolah_asal/edit', $data);
    }

    public function update($id)
    {
        $this->sekolahAsalModel->update($id, [
            'nama_sekolah' => $this->request->getPost('nama_sekolah'),
            'alamat' => $this->request->getPost('alamat')
        ]);

        return redirect()->to('sekolah-asal')->with('success', 'Data sekolah berhasil diupdate');
    }

    public function delete($id)
    {
        $this->sekolahAsalModel->delete($id);
        return redirect()->to('sekolah-asal')->with('success', 'Data sekolah berhasil dihapus');
    }
}