<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col">
            <h2>Dashboard PPDB SMK 11 Maret</h2>
            <p class="text-muted">Selamat datang, <?= session()->get('username') ?></p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Pendaftar</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_pendaftar ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Formulir Dikembalikan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_pengembalian ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Pembayaran</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Rp <?= number_format($total_pembayaran, 0, ',', '.') ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Jumlah Jurusan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total_jurusan ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-graduation-cap fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Statistik Pendaftaran per Jurusan</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="jurusanChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Status Pengembalian Formulir</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie">
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add new card for top 5 schools -->
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Top 5 Sekolah Asal Pendaftar</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="sekolahChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities Table -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Aktivitas Terbaru</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>No Pendaftaran</th>
                                    <th>Nama Siswa</th>
                                    <th>Jurusan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_activities as $activity): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($activity['created_at'])) ?></td>
                                    <td><?= $activity['no_pendaftaran'] ?></td>
                                    <td><?= $activity['nama_lengkap'] ?></td>
                                    <td><?= $activity['nama_jurusan'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $activity['status'] == 'Lengkap' ? 'success' : 'warning' ?>">
                                            <?= $activity['status'] ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Bar Chart
const jurusanCtx = document.getElementById('jurusanChart').getContext('2d');
new Chart(jurusanCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($jurusan_labels) ?>,
        datasets: [{
            label: 'Jumlah Pendaftar',
            data: <?= json_encode($jurusan_data) ?>,
            backgroundColor: 'rgba(78, 115, 223, 0.8)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

// Pie Chart
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['Lengkap', 'Belum Lengkap'],
        datasets: [{
            data: <?= json_encode($status_data) ?>,
            backgroundColor: ['#1cc88a', '#f6c23e']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Top 5 Schools Chart
const sekolahCtx = document.getElementById('sekolahChart').getContext('2d');
new Chart(sekolahCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($sekolah_labels) ?>,
        datasets: [{
            label: 'Jumlah Pendaftar',
            data: <?= json_encode($sekolah_data) ?>,
            backgroundColor: 'rgba(54, 185, 204, 0.8)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
</script>

<?= $this->endSection() ?>