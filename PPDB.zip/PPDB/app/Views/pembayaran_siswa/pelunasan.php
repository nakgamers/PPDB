<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-money-bill-wave me-2"></i>Pelunasan Pembayaran
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Informasi Siswa -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-user me-2"></i>Informasi Siswa
                            </h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td width="150">Nama Lengkap</td>
                                    <td>: <?= $siswa['nama_lengkap'] ?></td>
                                </tr>
                                <tr>
                                    <td>No Pendaftaran</td>
                                    <td>: <?= $siswa['no_pendaftaran'] ?></td>
                                </tr>
                                <tr>
                                    <td>Jurusan</td>
                                    <td>: <?= $siswa['nama_jurusan'] ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6 text-end">
                            <p class="mb-1">
                                <i class="fas fa-calendar me-2"></i>
                                Tanggal: <?= date('d/m/Y') ?>
                            </p>
                        </div>
                    </div>

                    <form action="<?= base_url('pembayaran-siswa/process-pelunasan') ?>" method="post">
                        <input type="hidden" name="pembayaran_detail_id" value="<?= $pembayaran_detail['id'] ?>">
                        
                        <!-- Ringkasan Pembayaran -->
                        <div class="card">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Ringkasan Pembayaran</h6>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <label class="col-sm-4">Total Setelah Diskon</label>
                                    <div class="col-sm-8">
                                        <span>Rp <?= number_format($pembayaran_detail['total_setelah_diskon'], 0, ',', '.') ?></span>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Total Sudah Dibayar</label>
                                    <div class="col-sm-8">
                                        <span>Rp <?= number_format($pembayaran_detail['jumlah_bayar'], 0, ',', '.') ?></span>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Sisa yang Harus Dibayar</label>
                                    <div class="col-sm-8">
                                        <span>Rp <?= number_format($pembayaran_detail['sisa_bayar'], 0, ',', '.') ?></span>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Jumlah Bayar</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="jumlah_bayar_display" id="jumlah_bayar_display" 
                                               value="<?= number_format($pembayaran_detail['sisa_bayar'], 0, ',', '.') ?>">
                                        <input type="hidden" name="jumlah_bayar" id="jumlah_bayar" 
                                               value="<?= $pembayaran_detail['sisa_bayar'] ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-end mt-4">
                            <a href="<?= base_url('pembayaran-siswa') ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Proses Pelunasan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const jumlahBayarDisplay = document.getElementById('jumlah_bayar_display');
    const jumlahBayar = document.getElementById('jumlah_bayar');

    jumlahBayarDisplay.addEventListener('input', function(e) {
        // Remove non-numeric characters
        let value = this.value.replace(/\D/g, '');
        
        // Format with thousand separator
        if (value !== '') {
            value = parseInt(value).toLocaleString('id-ID');
        }
        
        // Update display value
        this.value = value;
        
        // Update hidden input with numeric value only
        jumlahBayar.value = this.value.replace(/\D/g, '');
    });
});
</script>

<?= $this->endSection() ?>