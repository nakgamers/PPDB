<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Pembayaran Siswa</h2>
            
            <div class="card mb-4">
                <div class="card-body">
                    <form action="" method="get" class="row g-3">
                        <div class="col-md-3">
                            <label for="no_pendaftaran" class="form-label">No Pendaftaran</label>
                            <input type="text" class="form-control" id="no_pendaftaran" name="no_pendaftaran" 
                                   value="<?= $request->getGet('no_pendaftaran') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="nama_siswa" class="form-label">Nama Siswa</label>
                            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa"
                                   value="<?= $request->getGet('nama_siswa') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="jurusan" class="form-label">Jurusan</label>
                            <select class="form-select" id="jurusan" name="jurusan">
                                <option value="">Semua Jurusan</option>
                                <?php foreach($jurusan_list as $j): ?>
                                    <option value="<?= $j['id'] ?>" <?= $request->getGet('jurusan') == $j['id'] ? 'selected' : '' ?>>
                                        <?= $j['nama_jurusan'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">Cari</button>
                            <a href="<?= base_url('pembayaran-siswa/create') ?>" class="btn btn-secondary">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Add warning alert -->
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Data siswa yang ada di list ini adalah data siswa yang telah mengembalikan formulir. Apabila data anak tidak ada di list, kemungkinan belum mengembalikan formulir.
            </div>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="table-primary">
                        <tr class="text-center">
                            <th class="align-middle text-center" width="5%">No</th>
                            <th class="align-middle text-center" width="15%">No Pendaftaran</th>
                            <th class="align-middle" width="25%">Nama Siswa</th>
                            <th class="align-middle" width="25%">Nama Orang Tua</th>
                            <th class="align-middle text-center" width="20%">Jurusan</th>
                            <th class="align-middle text-center" width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pendaftaran as $key => $p): ?>
                            <tr>
                                <td class="text-center"><?= $key + 1 ?></td>
                                <td class="text-center"><?= $p['no_pendaftaran'] ?></td>
                                <td class="text-center"><?= $p['nama_lengkap'] ?></td>
                                <td class="text-center"><?= $p['nama_ortu'] ?></td>
                                <td class="text-center"><?= $p['nama_jurusan'] ?></td>
                                <td class="text-center">
                                    <a href="<?= base_url('pembayaran-siswa/detail/' . $p['id']) ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-money-bill-wave me-2"></i>Bayar
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<!-- Add these to the head section of your template -->
<style>
.hover-shadow:hover {
    box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
    transition: all 0.3s ease;
}

.payment-checkbox:checked + label {
    background-color: #e8f0fe;
    border-radius: 0.25rem;
    padding: 0.5rem;
}
</style>

<!-- Modal Pembayaran -->
<div class="modal fade" id="bayarModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-money-bill-wave me-2"></i>Form Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?= base_url('pembayaran-siswa/store') ?>" method="post">
                <div class="modal-body">
                    <input type="hidden" id="pendaftaran_id" name="pendaftaran_id">
                    
                    <div class="card mb-4">
                        <div class="card-body bg-light">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="text-primary">
                                        <i class="fas fa-user me-2"></i>Detail Siswa
                                    </h5>
                                    <div class="ms-3 mt-3">
                                        <p class="mb-2">
                                            <i class="fas fa-id-card me-2 text-secondary"></i>
                                            <strong>Nama:</strong> 
                                            <span id="modal_nama_siswa" class="text-dark ms-2"></span>
                                        </p>
                                        <p class="mb-0">
                                            <i class="fas fa-hashtag me-2 text-secondary"></i>
                                            <strong>No. Pendaftaran:</strong> 
                                            <span id="modal_no_pendaftaran" class="text-dark ms-2"></span>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-6 text-md-end">
                                    <p class="mb-1">
                                        <i class="fas fa-calendar me-2"></i>
                                        <strong>Tanggal:</strong> <?= date('d/m/Y') ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">
                                <i class="fas fa-list-ul me-2"></i>Rincian Pembayaran
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="pembayaran-options">
                                <?php foreach($pembayaran as $p): ?>
                                    <div class="form-check mb-3 p-3 border rounded hover-shadow">
                                        <input class="form-check-input payment-checkbox" type="checkbox" 
                                               name="pembayaran_id[]" 
                                               value="<?= $p['id'] ?>" 
                                               id="pembayaran_<?= $p['id'] ?>"
                                               data-jurusan="<?= $p['jurusan_id'] ?>"
                                               data-amount="<?= $p['jumlah'] ?>">
                                        <label class="form-check-label d-flex justify-content-between align-items-center w-100" 
                                               for="pembayaran_<?= $p['id'] ?>">
                                            <span class="fs-6">
                                                <i class="fas fa-money-bill-wave me-2 text-secondary"></i>
                                                <?= $p['nama_pembayaran'] ?>
                                            </span>
                                            <span class="badge bg-primary rounded-pill fs-6">
                                                Rp <?= number_format($p['jumlah'], 0, ',', '.') ?>
                                            </span>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="border-top pt-4 mt-3">
                                <div class="d-flex justify-content-between align-items-center bg-light p-3 rounded">
                                    <h5 class="mb-0">
                                        <i class="fas fa-calculator me-2"></i>Total Pembayaran:
                                    </h5>
                                    <h5 class="mb-0 text-primary">Rp <span id="total_amount">0</span></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Tutup
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Simpan Pembayaran
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('bayarModal').addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var id = button.getAttribute('data-id');
    var nama = button.getAttribute('data-nama');
    var noPendaftaran = button.getAttribute('data-nopendaftaran');
    var jurusanId = button.getAttribute('data-jurusan');
    
    document.getElementById('pendaftaran_id').value = id;
    document.getElementById('modal_nama_siswa').textContent = nama;
    document.getElementById('modal_no_pendaftaran').textContent = noPendaftaran;

    // Reset checkboxes and total
    document.querySelectorAll('.payment-checkbox').forEach(checkbox => {
        checkbox.checked = false;
        if (checkbox.getAttribute('data-jurusan') === jurusanId) {
            checkbox.closest('.form-check').style.display = '';
        } else {
            checkbox.closest('.form-check').style.display = 'none';
        }
    });
    calculateTotal();
});

// Calculate total when checkboxes are clicked
document.querySelectorAll('.payment-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', calculateTotal);
});

function calculateTotal() {
    let total = 0;
    document.querySelectorAll('.payment-checkbox:checked').forEach(checkbox => {
        total += parseInt(checkbox.getAttribute('data-amount'));
    });
    document.getElementById('total_amount').textContent = new Intl.NumberFormat('id-ID').format(total);
}
</script>

<?= $this->endSection() ?>