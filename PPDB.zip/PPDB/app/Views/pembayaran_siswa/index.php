<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Pembayaran Siswa</h2>
            <a href="<?= base_url('pembayaran-siswa/create') ?>" class="btn btn-primary mb-3">Tambah Pembayaran Siswa</a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="table-primary">
                        <tr class="text-center">
                            <th class="align-middle" width="5%">No</th>
                            <th class="align-middle" width="15%">Nama Siswa</th>
                            <th class="align-middle" width="15%">Nama Orang Tua</th>
                            <th class="align-middle" width="10%">Total Sebelum Diskon</th>
                            <th class="align-middle" width="8%">Total Diskon</th>
                            <th class="align-middle" width="10%">Total Setelah Diskon</th>
                            <th class="align-middle" width="10%">Jumlah Bayar</th>
                            <th class="align-middle" width="8%">Sisa Bayar</th>
                            <th class="align-middle" width="7%">Status</th>
                            <th class="align-middle" width="7%">Tanggal</th>
                            <th class="align-middle" width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pembayaran_detail as $key => $pd): ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $pd['nama_lengkap'] ?></td>
                                <td><?= $pd['nama_ortu'] ?></td>
                                <td>Rp <?= number_format($pd['total_sebelum_diskon'], 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($pd['total_diskon'], 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($pd['total_setelah_diskon'], 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($pd['jumlah_bayar'], 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($pd['sisa_bayar'], 0, ',', '.') ?></td>
                                <td>
                                    <span class="badge <?= $pd['sisa_bayar'] > 0 ? 'bg-warning' : 'bg-success' ?>">
                                        <?= $pd['sisa_bayar'] > 0 ? 'Belum Lunas' : 'Lunas' ?>
                                    </span>
                                </td>
                                <td><?= date('d/m/Y', strtotime($pd['created_at'])) ?></td>
                                <td>
                                    <a href="<?= base_url('pembayaran-siswa/pelunasan/' . $pd['id']) ?>" 
                                       class="btn btn-sm btn-success">Pelunasan</a>
                                    <a href="<?= base_url('pembayaran-siswa/delete/' . $pd['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>