<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-file-invoice me-2"></i>Detail Pembayaran Siswa
                    </h5>
                </div>
                <div class="card-body">
                    <!-- Informasi Siswa -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-user me-2"></i>Informasi Siswa
                            </h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td width="150">Nama Lengkap</td>
                                    <td>: <?= $siswa['nama_lengkap'] ?></td>
                                </tr>
                                <tr>
                                    <td>No Pendaftaran</td>
                                    <td>: <?= $siswa['no_pendaftaran'] ?></td>
                                </tr>
                                <tr>
                                    <td>Jurusan</td>
                                    <td>: <?= $siswa['nama_jurusan'] ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6 text-end">
                            <p class="mb-1">
                                <i class="fas fa-calendar me-2"></i>
                                Tanggal: <?= date('d/m/Y') ?>
                            </p>
                        </div>
                    </div>

                    <form action="<?= base_url('pembayaran-siswa/process') ?>" method="post">
                        <input type="hidden" name="pendaftaran_id" value="<?= $siswa['id'] ?>">
                        
                        <!-- Rincian Pembayaran -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-list-ul me-2"></i>Rincian Pembayaran</h6>
                            </div>
                            <div class="card-body">
                                <?php foreach($pembayaran as $p): ?>
                                    <div class="form-check mb-3 p-3 border rounded hover-shadow">
                                        <input class="form-check-input payment-item" type="checkbox" 
                                               name="pembayaran_id[]" 
                                               value="<?= $p['id'] ?>"
                                               data-amount="<?= $p['jumlah'] ?>">
                                        <label class="form-check-label d-flex justify-content-between w-100">
                                            <span><?= $p['nama_pembayaran'] ?></span>
                                            <span class="badge bg-primary rounded-pill">
                                                Rp <?= number_format($p['jumlah'], 0, ',', '.') ?>
                                            </span>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Diskon -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-percent me-2"></i>Diskon</h6>
                            </div>
                            <div class="card-body">
                                <select class="form-select" name="diskon_id" id="diskon">
                                    <option value="" data-tipe="persentase" data-jumlah="0">Diskon 0%</option>
                                    <?php foreach($diskon as $d): ?>
                                        <option value="<?= $d['id'] ?>" 
                                                data-tipe="<?= $d['tipe_diskon'] ?>"
                                                data-jumlah="<?= $d['jumlah_diskon'] ?>">
                                            <?= $d['nama_diskon'] ?> 
                                            (<?= $d['tipe_diskon'] == 'persentase' ? $d['jumlah_diskon'] . '%' : 'Rp ' . number_format($d['jumlah_diskon'], 0, ',', '.') ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Ringkasan Pembayaran -->
                        <div class="card">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Ringkasan Pembayaran</h6>
                            </div>
                            <div class="card-body">
                                <div class="row mb-3">
                                    <label class="col-sm-4">Total Sebelum Diskon</label>
                                    <div class="col-sm-8">
                                        <span>Rp </span><span id="total_before">0</span>
                                        <input type="hidden" name="total_sebelum_diskon" id="total_sebelum_diskon">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Total Diskon</label>
                                    <div class="col-sm-8">
                                        <span>Rp </span><span id="total_discount">0</span>
                                        <input type="hidden" name="total_diskon" id="total_diskon">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4">Total Setelah Diskon</label>
                                    <div class="col-sm-8">
                                        <span>Rp </span><span id="total_after">0</span>
                                        <input type="hidden" name="total_setelah_diskon" id="total_setelah_diskon">
                                    </div>
                                </div>
                                <!-- Change the jumlah bayar input field -->
                                <div class="row mb-3">
                                    <label class="col-sm-4">Jumlah Bayar</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="jumlah_bayar_display" id="jumlah_bayar_display">
                                        <input type="hidden" name="jumlah_bayar" id="jumlah_bayar">
                                    </div>
                                </div>

                                <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    const paymentItems = document.querySelectorAll('.payment-item');
                                    const diskonSelect = document.getElementById('diskon');
                                    const jumlahBayarDisplay = document.getElementById('jumlah_bayar_display');
                                    const jumlahBayar = document.getElementById('jumlah_bayar');
                                
                                    // Auto check all payment items on page load
                                    paymentItems.forEach(item => {
                                        item.checked = true;
                                    });
                                    
                                    // Handle format for jumlah bayar input
                                    jumlahBayarDisplay.addEventListener('input', function(e) {
                                        // Remove non-numeric characters
                                        let value = this.value.replace(/\D/g, '');
                                        
                                        // Format with thousand separator
                                        if (value !== '') {
                                            value = parseInt(value).toLocaleString('id-ID');
                                        }
                                        
                                        // Update display value
                                        this.value = value;
                                        
                                        // Update hidden input with numeric value only
                                        jumlahBayar.value = this.value.replace(/\D/g, '');
                                        
                                        // Calculate totals
                                        calculateTotals();
                                    });
                                    
                                    // Add pelunasan button handler
                                    document.getElementById('btn-pelunasan').addEventListener('click', function() {
                                        const totalAfter = parseInt(document.getElementById('total_setelah_diskon').value);
                                        jumlahBayarDisplay.value = totalAfter.toLocaleString('id-ID');
                                        jumlahBayar.value = totalAfter;
                                        calculateTotals();
                                    });
                                    
                                    // Calculate initial totals
                                    calculateTotals();
                                
                                    function calculateTotals() {
                                        let totalBefore = 0;
                                        paymentItems.forEach(item => {
                                            if (item.checked) {
                                                totalBefore += parseInt(item.dataset.amount);
                                            }
                                        });
                                
                                        let totalDiscount = 0;
                                        if (diskonSelect.value) {
                                            const option = diskonSelect.options[diskonSelect.selectedIndex];
                                            const tipe = option.dataset.tipe;
                                            const jumlah = parseFloat(option.dataset.jumlah);
                                
                                            if (tipe === 'persentase') {
                                                totalDiscount = totalBefore * (jumlah / 100);
                                            } else {
                                                totalDiscount = jumlah;
                                            }
                                        }
                                
                                        const totalAfter = totalBefore - totalDiscount;
                                        const bayar = parseInt(jumlahBayar.value) || 0;
                                        const remaining = totalAfter - bayar;
                                
                                        // Update displays
                                        document.getElementById('total_before').textContent = totalBefore.toLocaleString('id-ID');
                                        document.getElementById('total_discount').textContent = totalDiscount.toLocaleString('id-ID');
                                        document.getElementById('total_after').textContent = totalAfter.toLocaleString('id-ID');
                                        document.getElementById('remaining').textContent = remaining.toLocaleString('id-ID');
                                
                                        // Update hidden inputs
                                        document.getElementById('total_sebelum_diskon').value = totalBefore;
                                        document.getElementById('total_diskon').value = totalDiscount;
                                        document.getElementById('total_setelah_diskon').value = totalAfter;
                                        document.getElementById('sisa_bayar').value = remaining;
                                    }
                                
                                    paymentItems.forEach(item => item.addEventListener('change', calculateTotals));
                                    diskonSelect.addEventListener('change', calculateTotals);
                                });
                                </script>
                                <div class="row">
                                    <label class="col-sm-4">Sisa Bayar</label>
                                    <div class="col-sm-8">
                                        <span>Rp </span><span id="remaining">0</span>
                                        <input type="hidden" name="sisa_bayar" id="sisa_bayar">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="text-end mt-4">
                            <a href="<?= base_url('pembayaran-siswa') ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Proses Pembayaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>