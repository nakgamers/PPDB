<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <h2>Edit Pembayaran Siswa</h2>
            <form action="<?= base_url('pembayaran-siswa/update/' . $pembayaran_siswa['id']) ?>" method="post">
                <div class="mb-3">
                    <label for="pendaftaran_id" class="form-label">Nama Siswa</label>
                    <select class="form-select" id="pendaftaran_id" name="pendaftaran_id" required>
                        <option value="">Pilih Siswa</option>
                        <?php foreach($pendaftaran as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= ($pembayaran_siswa['pendaftaran_id'] == $p['id']) ? 'selected' : '' ?>>
                                <?= $p['nama_lengkap'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="pembayaran_id" class="form-label">Jenis Pembayaran</label>
                    <select class="form-select" id="pembayaran_id" name="pembayaran_id" required>
                        <option value="">Pilih Pembayaran</option>
                        <?php foreach($pembayaran as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= ($pembayaran_siswa['pembayaran_id'] == $p['id']) ? 'selected' : '' ?>>
                                <?= $p['nama_pembayaran'] ?> - Rp <?= number_format($p['jumlah'], 0, ',', '.') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="Belum Lunas" <?= ($pembayaran_siswa['status'] == 'Belum Lunas') ? 'selected' : '' ?>>Belum Lunas</option>
                        <option value="Lunas" <?= ($pembayaran_siswa['status'] == 'Lunas') ? 'selected' : '' ?>>Lunas</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="tanggal_bayar" class="form-label">Tanggal Bayar</label>
                    <input type="date" class="form-control" id="tanggal_bayar" name="tanggal_bayar" 
                           value="<?= $pembayaran_siswa['tanggal_bayar'] ?>">
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('pembayaran-siswa') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>