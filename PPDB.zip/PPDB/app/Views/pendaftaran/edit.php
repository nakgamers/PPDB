<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <h2>Edit Pendaftaran</h2>
            <form action="<?= base_url('pendaftaran/update/' . $pendaftaran['id']) ?>" method="post">
                <div class="mb-3">
                    <label class="form-label">Nomor Pendaftaran</label>
                    <input type="text" class="form-control" value="<?= $pendaftaran['no_pendaftaran'] ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" 
                           value="<?= $pendaftaran['nama_lengkap'] ?>" required>
                </div>

                <div class="mb-3">
                    <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                    <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="L" <?= $pendaftaran['jenis_kelamin'] == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="P" <?= $pendaftaran['jenis_kelamin'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                        <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" 
                               value="<?= $pendaftaran['tempat_lahir'] ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                        <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" 
                               value="<?= $pendaftaran['tanggal_lahir'] ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="sekolah_asal_id" class="form-label">Asal Sekolah</label>
                    <select class="form-select" id="sekolah_asal_id" name="sekolah_asal_id" required>
                        <?php foreach($sekolah as $s): ?>
                            <option value="<?= $s['id'] ?>" 
                                <?= $pendaftaran['sekolah_asal_id'] == $s['id'] ? 'selected' : '' ?>>
                                <?= $s['nama_sekolah'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="jurusan_id_1" class="form-label">Pilihan Jurusan</label>
                    <select class="form-select" id="jurusan_id_1" name="jurusan_id_1" required>
                        <option value="">Pilih Jurusan</option>
                        <?php foreach($jurusan as $j): ?>
                            <option value="<?= $j['id'] ?>" <?= ($pendaftaran['jurusan_id_1'] == $j['id']) ? 'selected' : '' ?>>
                                <?= $j['nama_jurusan'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="jenis_formulir" class="form-label">Jenis Formulir</label>
                    <select class="form-select" id="jenis_formulir" name="jenis_formulir" required>
                        <option value="">Pilih Jenis Formulir</option>
                        <option value="Gratis" <?= ($pendaftaran['jenis_formulir'] == 'Gratis') ? 'selected' : '' ?>>Gratis</option>
                        <option value="Bayar" <?= ($pendaftaran['jenis_formulir'] == 'Bayar') ? 'selected' : '' ?>>Bayar</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('pendaftaran') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>