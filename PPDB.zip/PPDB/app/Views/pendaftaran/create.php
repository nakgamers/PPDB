<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <h2>Data Pengambilan Form PPDB</h2>
            
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?= session()->get('error') ?>
                </div>
            <?php endif; ?>

            <form action="<?= base_url('pendaftaran/store') ?>" method="post">
                <?= csrf_field() ?>
                
                <div class="mb-3">
                    <label for="no_pendaftaran" class="form-label">Nomor Pendaftaran</label>
                    <input type="text" class="form-control" id="no_pendaftaran" name="no_pendaftaran" 
                           value="<?= $nomor_pendaftaran ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" required>
                </div>

                <div class="mb-3">
                    <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                    <select class="form-select" id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="">Pilih Jenis Kelamin</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                        <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" required>
                    </div>
                    <div class="col-md-6">
                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                        <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="sekolah_asal_id" class="form-label">Asal Sekolah</label>
                    <select class="form-select sekolah-select" id="sekolah_asal_id" name="sekolah_asal_id" required>
                        <option value="">Cari Sekolah Asal...</option>
                        <?php foreach($sekolah as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= $s['nama_sekolah'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="mt-2">
                        <small class="text-muted">Tidak menemukan sekolah? 
                            <a href="#" data-bs-toggle="modal" data-bs-target="#addSchoolModal">Tambah Sekolah Baru</a>
                        </small>
                    </div>
                </div>

                <!-- Lanjutkan form pendaftaran -->
                <div class="mb-3">
                    <label for="jurusan_id_1" class="form-label">Pilihan Jurusan</label>
                    <select class="form-select" id="jurusan_id_1" name="jurusan_id_1" required>
                        <option value="">Pilih Jurusan</option>
                        <?php foreach($jurusan as $j): ?>
                            <option value="<?= $j['id'] ?>"><?= $j['nama_jurusan'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <input type="hidden" name="jurusan_id_2" value="">

                <div class="mb-3">
                    <label for="no_hp" class="form-label">Nomor HP/WhatsApp</label>
                    <input type="text" class="form-control" id="no_hp" name="no_hp" required>
                </div>

                <div class="mb-3">
                    <label for="nama_ortu" class="form-label">Nama Orang Tua/Wali</label>
                    <input type="text" class="form-control" id="nama_ortu" name="nama_ortu" required>
                </div>

                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat Domisili</label>
                    <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                </div>

                <div class="mb-3">
                    <label for="kip_kks_pkh" class="form-label">Memiliki KIP/KKS/PKH?</label>
                    <select class="form-select" id="kip_kks_pkh" name="kip_kks_pkh" required>
                        <option value="">Pilih</option>
                        <option value="Ya">Ya</option>
                        <option value="Tidak">Tidak</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="jenis_formulir" class="form-label">Jenis Formulir</label>
                    <select class="form-select" id="jenis_formulir" name="jenis_formulir" required>
                        <option value="">Pilih Jenis Formulir</option>
                        <option value="Gratis">Gratis</option>
                        <option value="Bayar">Bayar</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= base_url('pendaftaran') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

<!-- Perbaiki struktur script di bagian bawah file -->
</div>

<!-- Modal di luar form utama -->
<div class="modal fade" id="addSchoolModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Sekolah Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="nama_sekolah" class="form-label">Nama Sekolah</label>
                    <input type="text" class="form-control" id="nama_sekolah" required>
                    <div id="namaSekolahFeedback" class="invalid-feedback"></div>
                </div>
                <div class="mb-3">
                    <label for="alamat_sekolah" class="form-label">Alamat Sekolah</label>
                    <textarea class="form-control" id="alamat_sekolah" rows="3" required></textarea>
                    <div id="alamatSekolahFeedback" class="invalid-feedback"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" onclick="saveSchool()">Simpan</button>
            </div>
        </div>
    </div>
</div>

<!-- Scripts di akhir -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function() {
    $('.sekolah-select').select2({
        placeholder: 'Cari Sekolah Asal...',
        allowClear: true,
        minimumInputLength: 2,
        language: {
            inputTooShort: function() {
                return 'Ketik minimal 2 karakter';
            },
            noResults: function() {
                return 'Sekolah tidak ditemukan';
            }
        }
    });
});

function checkNoPendaftaran(value) {
    fetch(`<?= base_url('pendaftaran/check-number/') ?>/${value}`)
        .then(response => response.json())
        .then(data => {
            const input = document.getElementById('no_pendaftaran');
            const feedback = document.getElementById('noPendaftaranFeedback');
            
            if (data.exists) {
                input.classList.add('is-invalid');
                input.classList.remove('is-valid');
                feedback.textContent = 'Nomor pendaftaran sudah digunakan';
                input.setCustomValidity('Nomor pendaftaran sudah digunakan');
            } else {
                input.classList.add('is-valid');
                input.classList.remove('is-invalid');
                feedback.textContent = '';
                input.setCustomValidity('');
            }
        });
}

function saveSchool() {
    const nama_sekolah = document.getElementById('nama_sekolah').value;
    const alamat_sekolah = document.getElementById('alamat_sekolah').value;

    if (!nama_sekolah || !alamat_sekolah) {
        if (!nama_sekolah) {
            document.getElementById('nama_sekolah').classList.add('is-invalid');
            document.getElementById('namaSekolahFeedback').textContent = 'Nama sekolah harus diisi';
        }
        if (!alamat_sekolah) {
            document.getElementById('alamat_sekolah').classList.add('is-invalid');
            document.getElementById('alamatSekolahFeedback').textContent = 'Alamat sekolah harus diisi';
        }
        return;
    }

    fetch('<?= base_url('sekolah-asal/store') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            'nama_sekolah': nama_sekolah,
            'alamat': alamat_sekolah,
            '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const newOption = new Option(data.school.nama_sekolah, data.school.id, true, true);
            $('.sekolah-select').append(newOption).trigger('change');
            
            alert('Sekolah berhasil ditambahkan!');
            
            $('#addSchoolModal').modal('hide');
            document.getElementById('nama_sekolah').value = '';
            document.getElementById('alamat_sekolah').value = '';
            document.getElementById('nama_sekolah').classList.remove('is-invalid');
            document.getElementById('alamat_sekolah').classList.remove('is-invalid');
        } else {
            alert('Gagal menambahkan sekolah: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat menyimpan data');
    });
}

// Form validation
document.querySelector('form').addEventListener('submit', function(e) {
    const noPendaftaran = document.getElementById('no_pendaftaran');
    if (noPendaftaran.classList.contains('is-invalid')) {
        e.preventDefault();
        alert('Harap perbaiki nomor pendaftaran yang sudah digunakan');
    }
});
</script>

<?= $this->endSection() ?>