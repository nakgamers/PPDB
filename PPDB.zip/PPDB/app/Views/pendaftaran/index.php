<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Pengambilan Form PPDB</h2>
            <a href="<?= base_url('pendaftaran/create') ?>" class="btn btn-primary mb-3">Tambah Data Yang Ambil Formulir</a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No. Pendaftaran</th>
                            <th>Nama Lengkap</th>
                            <th>Jenis Kelamin</th>
                            <th>Asal Sekolah</th>
                            <th>Jurusan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pendaftaran as $p): ?>
                            <tr>
                                <td>PPDB<?= str_pad($p['no_pendaftaran'], 4, '0', STR_PAD_LEFT) ?></td>
                                <td><?= $p['nama_lengkap'] ?></td>
                                <td><?= $p['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan' ?></td>
                                <td><?= $p['nama_sekolah'] ?></td>
                                <td><?= $p['jurusan_1'] ?></td>
                                <td>
                                    <a href="<?= base_url('pendaftaran/edit/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('pendaftaran/delete/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>