<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Sekolah Asal</h2>
            <a href="<?= base_url('sekolah-asal/create') ?>" class="btn btn-primary mb-3">Tambah Sekolah</a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Sekolah</th>
                            <th>Alamat</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($sekolah as $key => $s): ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $s['nama_sekolah'] ?></td>
                                <td><?= $s['alamat'] ?></td>
                                <td>
                                    <a href="<?= base_url('sekolah-asal/edit/' . $s['id']) ?>" 
                                       class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('sekolah-asal/delete/' . $s['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>