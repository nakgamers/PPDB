<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <h2>Edit Sekolah Asal</h2>
            <form action="<?= base_url('sekolah-asal/update/' . $sekolah['id']) ?>" method="post">
                <div class="mb-3">
                    <label for="nama_sekolah" class="form-label">Nama Sekolah</label>
                    <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" 
                           value="<?= $sekolah['nama_sekolah'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control" id="alamat" name="alamat" 
                              rows="3" required><?= $sekolah['alamat'] ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('sekolah-asal') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>