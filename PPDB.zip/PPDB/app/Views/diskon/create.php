<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plus me-2"></i>Tambah Diskon</h5>
                </div>
                <div class="card-body">
                    <form action="<?= base_url('diskon/store') ?>" method="post">
                        <div class="mb-3">
                            <label for="nama_diskon" class="form-label">Nama Diskon</label>
                            <input type="text" class="form-control" id="nama_diskon" name="nama_diskon" required>
                        </div>
                        <div class="mb-3">
                            <label for="jumlah_diskon" class="form-label">Jumlah Diskon</label>
                            <input type="number" class="form-control" id="jumlah_diskon" name="jumlah_diskon" required>
                        </div>
                        <div class="mb-3">
                            <label for="tipe_diskon" class="form-label">Tipe Diskon</label>
                            <select class="form-select" id="tipe_diskon" name="tipe_diskon" required>
                                <option value="nominal">Nominal (Rp)</option>
                                <option value="persentase">Persentase (%)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="aktif">Aktif</option>
                                <option value="nonaktif">Non Aktif</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Simpan
                        </button>
                        <a href="<?= base_url('diskon') ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Kembali
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>