<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Daftar Diskon</h2>
            <a href="<?= base_url('diskon/create') ?>" class="btn btn-primary mb-3">
                <i class="fas fa-plus me-2"></i>Tambah Diskon
            </a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Diskon</th>
                                    <th>Jumlah</th>
                                    <th>Tipe</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($diskon as $key => $d): ?>
                                    <tr>
                                        <td><?= $key + 1 ?></td>
                                        <td><?= $d['nama_diskon'] ?></td>
                                        <td><?= $d['tipe_diskon'] == 'persentase' ? $d['jumlah_diskon'] . '%' : 'Rp ' . number_format($d['jumlah_diskon'], 0, ',', '.') ?></td>
                                        <td><?= ucfirst($d['tipe_diskon']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $d['status'] == 'aktif' ? 'success' : 'danger' ?>">
                                                <?= ucfirst($d['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?= base_url('diskon/edit/' . $d['id']) ?>" 
                                               class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= base_url('diskon/delete/' . $d['id']) ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Apakah Anda yakin?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>