<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4" id="dataSiswaCard">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Data Siswa</h5>
                    <button class="btn btn-sm btn-light" id="toggleCard">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
                <div class="card-body">
                    <!-- Add filter form -->
                    <form action="" method="get" class="mb-4">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="no_pendaftaran">No Pendaftaran</label>
                                    <input type="text" class="form-control" name="no_pendaftaran" 
                                           value="<?= $_GET['no_pendaftaran'] ?? '' ?>" placeholder="Cari no pendaftaran...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="nama">Nama Siswa</label>
                                    <input type="text" class="form-control" name="nama" 
                                           value="<?= $_GET['nama'] ?? '' ?>" placeholder="Cari nama...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="nama_ortu">Nama Orang Tua</label>
                                    <input type="text" class="form-control" name="nama_ortu" 
                                           value="<?= $_GET['nama_ortu'] ?? '' ?>" placeholder="Cari nama orang tua...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="jurusan">Jurusan</label>
                                    <select class="form-select" name="jurusan">
                                        <option value="">Semua Jurusan</option>
                                        <?php foreach($jurusan as $j): ?>
                                            <option value="<?= $j['id'] ?>" 
                                                <?= (isset($_GET['jurusan']) && $_GET['jurusan'] == $j['id']) ? 'selected' : '' ?>>
                                                <?= $j['nama_jurusan'] ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Cari
                                </button>
                                <a href="<?= base_url('pengembalian-formulir/create') ?>" 
                                   class="btn btn-secondary">
                                    <i class="fas fa-redo"></i> Reset
                                </a>
                            </div>
                        </div>
                    </form>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="dataSiswa">
                            <thead class="table-primary">
                                <tr>
                                    <th>No</th>
                                    <th>No Pendaftaran</th>
                                    <th>Nama Lengkap</th>
                                    <th>Nama Orang Tua</th>
                                    <th>Jurusan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($pendaftaran as $key => $p): ?>
                                    <tr style="cursor: pointer" class="siswa-row" data-id="<?= $p['id'] ?>">
                                        <td><?= $key + 1 ?></td>
                                        <td><?= $p['no_pendaftaran'] ?></td>
                                        <td><?= $p['nama_lengkap'] ?></td>
                                        <td><?= $p['nama_ortu'] ?></td>
                                        <td><?= $p['nama_jurusan'] ?></td>
                                        <td>
                                            <a href="<?= base_url('pengembalian-formulir/detail/' . $p['id']) ?>" 
                                               class="btn btn-sm btn-primary">
                                                <i class="fas fa-check"></i> Pilih
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Tambah Data Pengembalian Formulir</h5>
                </div>
                <div class="card-body">
                    <form action="<?= base_url('pengembalian-formulir/store') ?>" method="post">
                        <div class="mb-3">
                            <label for="pendaftaran_id" class="form-label">Nama Siswa</label>
                            <select class="form-select" name="pendaftaran_id" id="pendaftaran_id" required>
                                <option value="">Pilih Siswa</option>
                                <?php foreach($pendaftaran as $p): ?>
                                    <option value="<?= $p['id'] ?>">
                                        <?= $p['no_pendaftaran'] ?> - <?= $p['nama_lengkap'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian</label>
                            <input type="date" class="form-control" id="tanggal_pengembalian" 
                                   name="tanggal_pengembalian" 
                                   value="<?= date('Y-m-d') ?>" 
                                   readonly
                                   required>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" name="status" id="status" required>
                                <option value="">Pilih Status</option>
                                <option value="Lengkap">Lengkap</option>
                                <option value="Belum Lengkap">Belum Lengkap</option>
                            </select>
                        </div>

                        <div class="text-end">
                            <a href="<?= base_url('pengembalian-formulir') ?>" class="btn btn-secondary">Kembali</a>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div> -->
        </div>
    </div>
</div>


<?= $this->endSection() ?> 