<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Detail Pengembalian Formulir</h5>
                    <span class="badge bg-light text-primary">No. Formulir: <?= $no_formulir ?></span>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h6 class="card-title border-bottom pb-2">Data Siswa</h6>
                                    <table class="table table-sm">
                                        <tr>
                                            <td style="width: 150px">No. Pendaftaran</td>
                                            <td>: <?= $pendaftaran['no_pendaftaran'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Nama Lengkap</td>
                                            <td>: <?= $pendaftaran['nama_lengkap'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Nama Orang Tua</td>
                                            <td>: <?= $pendaftaran['nama_ortu'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Jurusan</td>
                                            <td>: <?= $pendaftaran['nama_jurusan'] ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="card h-100">
                                <div class="card-body">
                                    <h6 class="card-title border-bottom pb-2">Form Pengembalian</h6>
                                    <form action="<?= base_url('pengembalian-formulir/store') ?>" method="post" id="formPengembalian">
                                        <input type="hidden" name="pendaftaran_id" value="<?= $pendaftaran['id'] ?>">
                                        <input type="hidden" name="no_formulir" value="<?= $no_formulir ?>">
                                        
                                        <div class="mb-3">
                                            <label class="form-label">Tanggal Pengembalian</label>
                                            <input type="date" class="form-control" name="tanggal_pengembalian" 
                                                   value="<?= date('Y-m-d') ?>" readonly>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Status Kelengkapan</label>
                                            <select class="form-select" name="status" id="status" required>
                                                <option value="">Pilih Status</option>
                                                <option value="Lengkap">Lengkap</option>
                                                <option value="Belum Lengkap">Belum Lengkap</option>
                                            </select>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title border-bottom pb-2">Checklist Dokumen</h6>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="50">No</th>
                                            <th>Dokumen</th>
                                            <th width="150">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $dokumen = [
                                            'Formulir Pendaftaran',
                                            'Fotokopi Ijazah/SKL',
                                            'Fotokopi Nilai Rapor',
                                            'Fotokopi Kartu Keluarga',
                                            'Fotokopi KTP Orang Tua',
                                            'Pas Foto 3x4 (4 lembar)',
                                            'Fotokopi NISN',
                        
                                            'Fotokopi Akta Kelahiran'
                                            
                                        ];
                                        foreach($dokumen as $key => $doc): 
                                        ?>
                                        <tr>
                                            <td class="text-center"><?= $key + 1 ?></td>
                                            <td><?= $doc ?></td>
                                            <td>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="dokumen[]" value="<?= $key ?>"
                                                           form="formPengembalian"
                                                           onchange="updateStatus()">
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="text-end mt-3">
                                <a href="<?= base_url('pengembalian-formulir/create') ?>" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Kembali
                                </a>
                                <button type="submit" form="formPengembalian" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Simpan Data
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function updateStatus() {
    const checkboxes = document.querySelectorAll('input[name="dokumen[]"]');
    const statusSelect = document.getElementById('status');
    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
    
    statusSelect.value = allChecked ? 'Lengkap' : 'Belum Lengkap';
}
</script>

<?= $this->endSection() ?>