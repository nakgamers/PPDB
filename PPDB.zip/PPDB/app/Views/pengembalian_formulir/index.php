<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Pengembalian Formulir</h2>
            <a href="<?= base_url('pengembalian-formulir/create') ?>" class="btn btn-primary mb-3">
                <i class="fas fa-plus"></i> Tambah Data
            </a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="table-primary">
                        <tr class="text-center">
                            <th class="align-middle text-center" width="5%">No</th>
                            <th class="align-middle text-center" width="15%">No Pendaftaran</th>
                            <th class="align-middle ps-3" width="25%">Nama Siswa</th>
                            <th class="align-middle ps-3" width="20%">Nama Orang Tua</th>
                            <th class="align-middle text-center" width="15%">Tanggal Pengembalian</th>
                            <th class="align-middle text-center" width="10%">Status</th>
                            <th class="align-middle text-center" width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($pengembalian_formulir ?? [] as $key => $pf): ?>
                            <tr class="align-middle">
                                <td class="text-center"><?= $key + 1 ?></td>
                                <td class="text-center"><?= $pf['no_pendaftaran'] ?></td>
                                <td class="text-center"><?= $pf['nama_lengkap'] ?></td>
                                <td class="text-center"><?= $pf['nama_ortu'] ?></td>
                                <td class="text-center"><?= date('d/m/Y', strtotime($pf['tanggal_pengembalian'])) ?></td>
                                <td class="text-center">
                                    <span class="badge <?= $pf['status'] == 'Lengkap' ? 'bg-success' : 'bg-warning' ?>">
                                        <?= $pf['status'] ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group">
                                        <a href="<?= base_url('pengembalian-formulir/edit/' . $pf['id']) ?>" 
                                           class="btn btn-sm btn-warning me-1">
                                           <i class="fas fa-edit"></i> Edit</a>
                                        <a href="<?= base_url('pengembalian-formulir/delete/' . $pf['id']) ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Apakah Anda yakin?')">
                                           <i class="fas fa-trash"></i> Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>