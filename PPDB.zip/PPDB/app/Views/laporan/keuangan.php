<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Laporan Keuangan</h2>

            <!-- Total Income Card -->
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h4 class="text-primary mb-0">Total Pemasukan</h4>
                            <h2 class="mt-2 mb-0">Rp <?= number_format($total_pemasukan, 0, ',', '.') ?></h2>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Summary by Type -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ringkasan per Jenis Pembayaran</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie mb-4">
                        <canvas id="paymentTypeChart"></canvas>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Jenis Pembayaran</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($summary_per_jenis as $s): ?>
                                <tr>
                                    <td><?= $s['nama_pembayaran'] ?></td>
                                    <td class="text-end">Rp <?= number_format($s['total'], 0, ',', '.') ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Detailed Payment Records -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Pembayaran</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>No Pendaftaran</th>
                                    <th>Nama Siswa</th>
                                    <th>Jenis Pembayaran</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($pembayaran_detail as $pd): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($pd['created_at'])) ?></td>
                                    <td><?= $pd['no_pendaftaran'] ?></td>
                                    <td><?= $pd['nama_lengkap'] ?></td>
                                    <td><?= $pd['nama_pembayaran'] ?></td>
                                    <td class="text-end">Rp <?= number_format($pd['jumlah_bayar'], 0, ',', '.') ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Pie Chart - Payment Types
const paymentTypeCtx = document.getElementById('paymentTypeChart').getContext('2d');
new Chart(paymentTypeCtx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($summary_per_jenis, 'nama_pembayaran')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($summary_per_jenis, 'total')) ?>,
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>

<?= $this->endSection() ?>