<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Data Calon Siswa</h2>
            
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable">
                            <thead class="table-primary">
                                <tr>
                                    <th>No Pendaftaran</th>
                                    <th>Nama Lengkap</th>
                                    <th>Nama Orang Tua</th>
                                    <th>Jurusan</th>
                                    <th>Sekolah Asal</th>
                                    <th>Status Pembayaran</th>
                                    <th>Status Formulir</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($siswa as $s): 
                                    $status_bayar = ($s['total_bayar'] >= $s['total_harus_bayar']) ? 'Lunas' : 'Belum Lunas';
                                    $status_formulir = $s['status_formulir'] ?? 'Belum Dikembalikan';
                                ?>
                                <tr>
                                    <td><?= $s['no_pendaftaran'] ?></td>
                                    <td><?= $s['nama_lengkap'] ?></td>
                                    <td><?= $s['nama_ortu'] ?></td>
                                    <td><?= $s['nama_jurusan'] ?></td>
                                    <td><?= $s['nama_sekolah'] ?></td>
                                    <td>
                                        <span class="badge bg-<?= $status_bayar == 'Lunas' ? 'success' : 'warning' ?>">
                                            <?= $status_bayar ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?= $status_formulir == 'Lengkap' ? 'success' : 'warning' ?>">
                                            <?= $status_formulir ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#dataTable').DataTable();
});
</script>

<?= $this->endSection() ?>