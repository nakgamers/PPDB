<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Statistik Calon Siswa</h2>
            
            <!-- Distribution by Major -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi per Jurusan</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="jurusanChart"></canvas>
                    </div>
                    <div class="table-responsive mt-3">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Jurusan</th>
                                    <th>Jumlah Pendaftar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($per_jurusan as $j): ?>
                                <tr>
                                    <td><?= $j['nama_jurusan'] ?></td>
                                    <td class="text-center"><?= $j['total'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Distribution by School -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi per Sekolah Asal</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar">
                        <canvas id="sekolahChart"></canvas>
                    </div>
                    <div class="table-responsive mt-3">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Sekolah Asal</th>
                                    <th>Jumlah Siswa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($per_sekolah as $s): ?>
                                <tr>
                                    <td><?= $s['nama_sekolah'] ?></td>
                                    <td class="text-center"><?= $s['total'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Form Status -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Status Pengembalian Formulir</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="chart-pie">
                                <canvas id="statusChart"></canvas>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="chart-pie">
                                <canvas id="statusPercentageChart"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive mt-3">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>Status</th>
                                    <th>Jumlah</th>
                                    <th>Persentase</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total = $status_formulir['lengkap'] + $status_formulir['belum_lengkap'];
                                $persen_lengkap = $total > 0 ? round(($status_formulir['lengkap'] / $total) * 100, 1) : 0;
                                $persen_belum = $total > 0 ? round(($status_formulir['belum_lengkap'] / $total) * 100, 1) : 0;
                                ?>
                                <tr>
                                    <td>Lengkap</td>
                                    <td class="text-center"><?= $status_formulir['lengkap'] ?></td>
                                    <td class="text-center"><?= $persen_lengkap ?>%</td>
                                </tr>
                                <tr>
                                    <td>Belum Lengkap</td>
                                    <td class="text-center"><?= $status_formulir['belum_lengkap'] ?></td>
                                    <td class="text-center"><?= $persen_belum ?>%</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Bar Chart - Jurusan
const jurusanCtx = document.getElementById('jurusanChart').getContext('2d');
new Chart(jurusanCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($per_jurusan, 'nama_jurusan')) ?>,
        datasets: [{
            label: 'Jumlah Pendaftar',
            data: <?= json_encode(array_column($per_jurusan, 'total')) ?>,
            backgroundColor: 'rgba(78, 115, 223, 0.8)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: { stepSize: 1 }
            }
        }
    }
});

// Bar Chart - Sekolah
const sekolahCtx = document.getElementById('sekolahChart').getContext('2d');
new Chart(sekolahCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($per_sekolah, 'nama_sekolah')) ?>,
        datasets: [{
            label: 'Jumlah Siswa',
            data: <?= json_encode(array_column($per_sekolah, 'total')) ?>,
            backgroundColor: 'rgba(54, 185, 204, 0.8)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: { stepSize: 1 }
            }
        }
    }
});

// Pie Chart - Status
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['Lengkap', 'Belum Lengkap'],
        datasets: [{
            data: [<?= $status_formulir['lengkap'] ?>, <?= $status_formulir['belum_lengkap'] ?>],
            backgroundColor: ['#1cc88a', '#f6c23e']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Percentage Pie Chart - Status
const statusPercentageCtx = document.getElementById('statusPercentageChart').getContext('2d');
new Chart(statusPercentageCtx, {
    type: 'pie',
    data: {
        labels: ['Lengkap (' + <?= $persen_lengkap ?> + '%)', 'Belum Lengkap (' + <?= $persen_belum ?> + '%)'],
        datasets: [{
            data: [<?= $persen_lengkap ?>, <?= $persen_belum ?>],
            backgroundColor: ['#1cc88a', '#f6c23e']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>

<?= $this->endSection() ?>