<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">PPDB System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('dashboard') ?>">
                        <i class="fas fa-home me-1"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pendaftaran') ?>">
                        <i class="fas fa-user-plus me-1"></i>Data Pengambilan Form
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pengembalian-formulir') ?>">
                        <i class="fas fa-file-alt me-1"></i>Pengembalian Formulir
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pembayaran-siswa') ?>">
                        <i class="fas fa-money-bill-wave me-1"></i>Pembayaran Siswa
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="reportsDropdown" role="button" 
                       data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-chart-bar me-1"></i>Laporan
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="reportsDropdown">
                        <li><a class="dropdown-item" href="<?= base_url('laporan/data-siswa') ?>">
                            <i class="fas fa-user-graduate me-1"></i>Data Calon Siswa</a></li>
                        <li><a class="dropdown-item" href="<?= base_url('laporan/statistik-siswa') ?>">
                            <i class="fas fa-users me-1"></i>Statistik Calon Siswa</a></li>
                        <li><a class="dropdown-item" href="<?= base_url('laporan/keuangan') ?>">
                            <i class="fas fa-money-bill-wave me-1"></i>Laporan Keuangan</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="dataMasterDropdown" role="button" 
                       data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-database me-1"></i>Data Master
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dataMasterDropdown">
                        <li><a class="dropdown-item" href="<?= base_url('jurusan') ?>">
                            <i class="fas fa-graduation-cap me-1"></i>Jurusan</a></li>
                        <li><a class="dropdown-item" href="<?= base_url('pembayaran') ?>">
                            <i class="fas fa-money-check-alt me-1"></i>Pembayaran</a></li>
                        <li><a class="dropdown-item" href="<?= base_url('diskon') ?>">
                            <i class="fas fa-percent me-1"></i>Diskon</a></li>
                        <li><a class="dropdown-item" href="<?= base_url('sekolah-asal') ?>">
                            <i class="fas fa-school me-1"></i>Sekolah Asal</a></li>
                    </ul>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('logout') ?>">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>