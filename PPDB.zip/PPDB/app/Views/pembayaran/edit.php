<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <h2>Edit Pembayaran</h2>
            <form action="<?= base_url('pembayaran/update/' . $pembayaran['id']) ?>" method="post">
                <div class="mb-3">
                    <label for="jurusan_id" class="form-label">Jurusan</label>
                    <select class="form-select" id="jurusan_id" name="jurusan_id" required>
                        <option value="">Pilih Jurusan</option>
                        <?php foreach($jurusan as $j): ?>
                            <option value="<?= $j['id'] ?>" <?= ($pembayaran['jurusan_id'] == $j['id']) ? 'selected' : '' ?>>
                                <?= $j['nama_jurusan'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="nama_pembayaran" class="form-label">Jenis Pembayaran</label>
                    <select class="form-select" id="nama_pembayaran" name="nama_pembayaran" required>
                        <option value="">Pilih Jenis Pembayaran</option>
                        <?php 
                        $jenis = ['SPP', 'Uang Pangkal', 'Seragam', 'MPLS'];
                        foreach($jenis as $j): 
                        ?>
                            <option value="<?= $j ?>" <?= ($pembayaran['nama_pembayaran'] == $j) ? 'selected' : '' ?>>
                                <?= $j ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="jumlah" class="form-label">Jumlah</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="text" class="form-control" id="jumlah" name="jumlah" 
                               value="<?= number_format($pembayaran['jumlah'], 0, ',', '.') ?>"
                               required onkeyup="formatRupiah(this)">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('pembayaran') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

<script>
function formatRupiah(input) {
    let value = input.value.replace(/[^\d]/g, '');
    input.value = new Intl.NumberFormat('id-ID').format(value);
}
</script>

<?= $this->endSection() ?>