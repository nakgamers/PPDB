<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">
            <h2>Tambah Pembayaran</h2>
            <form action="<?= base_url('pembayaran/store') ?>" method="post">
                <div class="mb-4">
                    <label for="jurusan_id" class="form-label">Jurusan</label>
                    <select class="form-select" id="jurusan_id" name="jurusan_id" required>
                        <option value="">Pilih Jurusan</option>
                        <?php foreach($jurusan as $j): ?>
                            <option value="<?= $j['id'] ?>"><?= $j['nama_jurusan'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Rincian Pembayaran</h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $jenis_pembayaran = ['SPP', 'Uang Pangkal', 'Seragam', 'MPLS', 'Wear Pack'];
                        foreach($jenis_pembayaran as $index => $jenis): 
                        ?>
                            <div class="mb-3 border-bottom pb-3">
                                <div class="row align-items-center">
                                    <div class="col-md-4">
                                        <label class="form-label"><?= $jenis ?></label>
                                        <input type="hidden" name="nama_pembayaran[]" value="<?= $jenis ?>">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="input-group">
                                            <span class="input-group-text">Rp</span>
                                            <input type="text" class="form-control rupiah" 
                                                   name="jumlah[]" 
                                                   id="jumlah_<?= $index ?>" 
                                                   onkeyup="formatRupiah(this)">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="mt-3">
                    <button type="submit" class="btn btn-primary">Simpan Semua</button>
                    <a href="<?= base_url('pembayaran') ?>" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function formatRupiah(input) {
    let value = input.value.replace(/[^\d]/g, '');
    input.value = new Intl.NumberFormat('id-ID').format(value);
}

document.getElementById('jurusan_id').addEventListener('change', function() {
    const jurusanId = this.value;
    if (!jurusanId) return;

    // Reset all inputs
    document.querySelectorAll('input[name="jumlah[]"]').forEach(input => {
        input.value = '';
    });

    // Fetch existing payments for this jurusan
    fetch(`<?= base_url('pembayaran/getJurusanPayments') ?>/${jurusanId}`)
        .then(response => response.json())
        .then(payments => {
            payments.forEach(payment => {
                // Find the matching input field
                const inputs = document.querySelectorAll('input[name="nama_pembayaran[]"]');
                inputs.forEach((input, index) => {
                    if (input.value === payment.nama_pembayaran) {
                        // Set the amount in the corresponding jumlah field
                        const jumlahInput = document.getElementById(`jumlah_${index}`);
                        jumlahInput.value = new Intl.NumberFormat('id-ID').format(payment.jumlah);
                    }
                });
            });
        });
});
</script>

<?= $this->endSection() ?>