<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Daftar Pembayaran</h2>
            <a href="<?= base_url('pembayaran/create') ?>" class="btn btn-primary mb-3">Tambah Pembayaran</a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Jurusan</th>
                            <th>Jenis Pembayaran</th>
                            <th>Jumlah</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $currentJurusan = '';
                        $counter = 1;
                        $subCounter = 1;
                        $rowspan = 0;
                        
                        $jurusanCount = [];
                        foreach($pembayaran as $p) {
                            if(!isset($jurusanCount[$p['nama_jurusan']])) {
                                $jurusanCount[$p['nama_jurusan']] = 0;
                            }
                            $jurusanCount[$p['nama_jurusan']]++;
                        }

                        foreach($pembayaran as $p): 
                            if($currentJurusan !== $p['nama_jurusan']):
                                $currentJurusan = $p['nama_jurusan'];
                                $rowspan = $jurusanCount[$currentJurusan];
                                $subCounter = 1;
                        ?>
                            <tr>
                                <td><?= $counter ?></td>
                                <td class="align-middle text-center" rowspan="<?= $rowspan ?>"><?= $currentJurusan ?></td>
                                <td><?= $subCounter . '. ' . $p['nama_pembayaran'] ?></td>
                                <td>Rp <?= number_format($p['jumlah'], 0, ',', '.') ?></td>
                                <td>
                                    <a href="<?= base_url('pembayaran/edit/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('pembayaran/delete/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td><?= $counter ?></td>
                                <td><?= ++$subCounter . '. ' . $p['nama_pembayaran'] ?></td>
                                <td>Rp <?= number_format($p['jumlah'], 0, ',', '.') ?></td>
                                <td>
                                    <a href="<?= base_url('pembayaran/edit/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('pembayaran/delete/' . $p['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                                </td>
                            </tr>
                        <?php 
                            endif;
                            $counter++;
                        endforeach; 
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>