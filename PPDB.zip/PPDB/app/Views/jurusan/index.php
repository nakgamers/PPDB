<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col">
            <h2>Daftar Jurusan</h2>
            <a href="<?= base_url('jurusan/create') ?>" class="btn btn-primary mb-3">Tambah Jurusan</a>
            
            <?php if(session()->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Jurusan</th>
                            <th>Detail</th>
                            <th>Foto</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jurusan as $key => $j): ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $j['nama_jurusan'] ?></td>
                                <td><?= $j['detail_jurusan'] ?></td>
                                <td>
                                    <?php if($j['foto_jurusan']): ?>
                                        <img src="<?= base_url('uploads/jurusan/' . $j['foto_jurusan']) ?>" 
                                             alt="<?= $j['nama_jurusan'] ?>" 
                                             width="100">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('jurusan/edit/' . $j['id']) ?>" 
                                       class="btn btn-sm btn-warning">Edit</a>
                                    <a href="<?= base_url('jurusan/delete/' . $j['id']) ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>