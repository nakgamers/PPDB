<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<?= $this->include('layout/navbar') ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6">
            <h2>Edit Jurusan</h2>
            <form action="<?= base_url('jurusan/update/' . $jurusan['id']) ?>" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="nama_jurusan" class="form-label">Nama Jurusan</label>
                    <input type="text" class="form-control" id="nama_jurusan" name="nama_jurusan" 
                           value="<?= $jurusan['nama_jurusan'] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="detail_jurusan" class="form-label">Detail Jurusan</label>
                    <textarea class="form-control" id="detail_jurusan" name="detail_jurusan" rows="3" required><?= $jurusan['detail_jurusan'] ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="foto_jurusan" class="form-label">Foto Jurusan</label>
                    <?php if($jurusan['foto_jurusan']): ?>
                        <div class="mb-2">
                            <img src="<?= base_url('uploads/jurusan/' . $jurusan['foto_jurusan']) ?>" 
                                 alt="Current Photo" width="200">
                        </div>
                    <?php endif; ?>
                    <input type="file" class="form-control" id="foto_jurusan" name="foto_jurusan" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('jurusan') ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>